# ÖZNUR STUDIO PRO — V2

V2 is a corrective build of the V1 APK/GitHub package.

## Fixed
- Native ZIP icon paths no longer contain accidental base64 data.
- PWA Service Worker cache list uses real relative file paths.
- Native package contains `package-lock.json` for `npm ci`.
- Android WebView supports HTML file chooser.
- Android WebView supports downloads through DownloadManager.
- Custom launcher icon added.
- Android 12+ splash icon/background added.
- APK version bumped to 2.0 / versionCode 2.
- Native Android workflow uses Java 21 and Gradle/Capacitor flow.
- Native workflow builds a real debug `base.apk`.

## Verified statically
- JavaScript source parses.
- Android project structure is preserved.
- Exporter functions contain no base64-derived file names.
- Service Worker cache URLs are relative paths.
- Android Manifest references the bundled icon.
- GitHub Actions workflow has an explicit Android build path.

## Important
The generated native/iOS source package still requires platform signing/build infrastructure.
iOS signed IPA requires macOS + Xcode.


## FINAL BUILD
- GitHub Actions workflow hardened for manual and main/master builds.
- Build verifies the APK exists before upload.
- Artifact is exposed as `base-apk` and contains exactly `base.apk`.
