# ÖZNUR STUDIO PRO — FINAL APK BUILD

Bu paket GitHub Actions ile gerçek Android APK üretmek için hazırlanmıştır.

## Çıktı
Build tamamlandığında:

`base.apk`

oluşur ve GitHub Actions içinde **Artifacts → base-apk** olarak indirilebilir.

## Telefonda kullanım
1. Bu klasörün içeriğini GitHub reposuna yükle.
2. Actions sekmesine gir.
3. **Build base.apk** workflow'unu çalıştır.
4. İşlem tamamlanınca **base-apk** artifact'ini aç.
5. İçindeki `base.apk` dosyasını telefona indir.

## Paket
- Android applicationId: `com.oznur.studio`
- Version: 2.0
- Target SDK: 35
- Min SDK: 23
- Java: 17
- Gradle: 8.11.1
- APK: debug build, dosya adı `base.apk`

Not: Bu sohbet ortamında Android SDK/Gradle build zinciri olmadığı için APK'nın kendisi burada derlenmemiştir; bu paket GitHub'ın Ubuntu runner'ında otomatik olarak derlenir.
